# missing-audit-log-lambda

Creates new lambda called `missing-audit-log-lambda`. This lambda queries the database table `hdb_catalog.event_log` to
find `tries` greater than 1 while `error` is true. It then filters these by `trigger_name` of "project" and "work_order_audit_log"
that have a new status of "COMPLETE". The results represent any failed attempt to update the `audit_log`. We're hoping
to find failed attempts as it effects our Netsuites Report.

This lambda is set to run once a day at 6am PST.

If the a failed audit_log attempt is found the lambda will throw an error. There is a cloudwatch alarm set up for the Error metric on this
lambda which will send an alert to slack channel `#AWS-{env}-alerts` channel.

## AWS Infrastructure

In Monitoring.ts, there is a `createMissingAuditLogLambda()` function that handles creating the AWS resources required for this integration to work.  
It defines the Lambda function, the IAM role it executes under, and the EventBridge rule that will trigger the lambda to be scheduled at 6am PST every day.  
For documentation about EventBridge rules, see the following links:

- [Example of how value matching works for EventBridge rules](https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-event-patterns.html#eb-filtering-data-types)
- [Example of an event that's emitted when a CodePipeline Action fails](https://docs.aws.amazon.com/codepipeline/latest/userguide/detect-state-changes-cloudwatch-events.html#detect-state-events-action-failed)

## Logging

The CloudWatch log group that the lambda logs to is `/aws/lambda/missing-audit-log-lambda`.
