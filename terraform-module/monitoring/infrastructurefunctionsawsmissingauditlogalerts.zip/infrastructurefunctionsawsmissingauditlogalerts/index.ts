import { Handler } from 'aws-lambda';
import * as AWS from 'aws-sdk';
import { getSSMParamValue } from './awsUtils';
import knex from 'knex';

export const handler: Handler = async (event, context, callback) => {
  const ssm = new AWS.SSM({ region: 'us-east-1' });

  // @ts-ignore
  const postgresDbUrl = await getSSMParamValue(ssm, `/kms-opus-one-${process.env.ENV}/DATABASE_URL`);
  // parse the connection URL string since knex defaults 'host' to localhost even though the url has a host
  const [pgUser, pgPass, pgHost, pgPort, pgDb] = postgresDbUrl.split(/[:/@]/g).slice(3);
  const postgresClient = knex({
    client: 'pg',
    connection: {
      host: pgHost,
      port: parseInt(pgPort),
      user: pgUser,
      password: pgPass,
      database: pgDb,
    },
  });

  const result = await postgresClient.raw(
    "SELECT table_name, trigger_name, error, tries, payload FROM hdb_catalog.event_log WHERE tries > 1 AND error = TRUE AND trigger_name IN ('project', 'work_order_audit_log')",
  );

  const data = result?.rows
    .filter((row: any) => {
      return (
        (row?.payload?.data.old?.status !== 'COMPLETE' && row?.payload?.data.new?.status === 'COMPLETE') ||
        (row.trigger_name === 'work_order_audit_log' &&
          row?.payload?.data?.old?.status !== 'QC_COMPLETE' &&
          row?.payload?.data?.new?.status === 'QC_COMPLETE')
      );
    })
    .map((row: any) => ({
      resourceId: row?.payload?.data?.new?.id,
      table: row?.table_name,
      oldStatus: row?.payload?.data.old?.status,
      newStatus: row?.payload?.data?.new?.status,
      updatedAt: row?.payload.data?.new?.updatedAt,
      tries: row?.tries,
    }));

  if (data?.length > 0) {
    console.log(`Validation Errors: ${JSON.stringify(data)}`);
    const error = new Error(`Validation Errors encountered: ${JSON.stringify(data)}`);
    callback(error);
    throw error;
  }

  callback(null, 'success');
};
